// Dominick Camareno
#include <iostream>

using namespace std;

int main() {
    
    char letter = 'a';
    while (letter != 'x') {
        
        // to make it more user friendly
        // tell the user that entering x would exit the program
        
        cout << "Please enter a letter(x to exit): ";
        cin >> letter;
        cout << "The letter you entered is " << letter << endl;
    }
    
    return 0;
}