#include <iostream>
using namespace std;

int main()
{
    int n; // declaring n
    int m; // declaring m

    cout<<"Enter the value of n "<<endl; // asking for value of n
    cin>>n; // taking its input

    cout<<"Enter the value of m "<<endl; // asking for value of m
    cin>>m; // taking its input

    int total; // to store total of all numbers
    int i; // variable which will be used in for-loop
    int numbers; // to store the amount/quantity of numbers
    float mean; // to store the mean

    for(i=n ; i<=m; i++)
    total = total +i; // calculating total

    numbers = m-n+1;
    mean = static_cast<float>(total) / numbers; // calculating mean, static_cast<float>(total) is important

    cout << "The mean of consecutive number from " << n <<" to " << m <<" is "<<mean; // print the result

    return 0;
}