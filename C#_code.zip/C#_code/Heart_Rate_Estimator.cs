using System;

using System;

namespace HeartRatesEstimator
{
    class HeartRates
    {
        // Declare attributes
        private string first_name;
        private string last_name;
        private int year_of_birth;
        private int current_year;

        //Declare and initialize variables for min and max heart rates percentage
        private float MinHeartRatePercentage = 0.5f;
        private float MaxHeartRatePercentage = 0.85f;
        private int MaxHeartRateFactor = 220;

        public HeartRates( string FirstName, string LastName, int YearOfBirth, int CurrentYear)
        {
            // Initialize the person's info
            first_name = FirstName;
            last_name = LastName;
            year_of_birth = YearOfBirth;
            current_year = CurrentYear;

        }

        //Decclare properties for setting and getting the attributes
        public string FirstName
        {
            get
            {
                return first_name;
            }
            set
            {
                first_name = value;
            }
        }

        public string LastName
        {
            get
            {
                return last_name;
            }
            set
            {
                last_name = value;
            }
        }

        public int YearOfBirth
        {
            get
            {
                return year_of_birth;
            }
            set
            {
                year_of_birth = value;
            }
        }

        public int CurrentYear
        {
            get
            {
                return current_year;
            }
            set
            {
                current_year = value;
            }
        }

        

        //Declare methods       
        
        public int getAge()
        {
            /// Method to caluclate and returns the person's age in years
            int age = current_year - year_of_birth;
            return age;
        }

        public int getMaxHeartRate()
        {
            ///Method to calculate and return the Maximum Heart Rate 

            int age = getAge();
            int maxHeartRate = MaxHeartRateFactor - age;

            return maxHeartRate;
        }

        public int getMinTargetHeartRate()
        {
            ///Method to calculate and return the minimum target heart rate
            
            int minTargetHeartRate;
            int maxHeartRate;

            maxHeartRate = getMaxHeartRate();
            minTargetHeartRate = (int)(MinHeartRatePercentage * maxHeartRate);

            return minTargetHeartRate;
        }

        public int getMaxTargetHeartRate()
        {
            ///Method to calculate and return the maximum target heart rate

            int maxTargetHeartRate;
            int maxHeartRate;

            maxHeartRate = getMaxHeartRate();
            maxTargetHeartRate = (int)(MaxHeartRatePercentage * maxHeartRate);

            return maxTargetHeartRate;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            int validInput = 0;

            // initialize variables
            string firstName;
            string lastName;
            int yearOfBirth =0;
            int currentYear =0;

            //int age, maxHeartRate, minTargetHeartRate, maxtargetHeartRate;



            Console.WriteLine("Enter the person's information: ");
                
            Console.Write("First Name: ");                
            firstName = Console.ReadLine();
                
            Console.Write("Last Name: ");
            lastName = Console.ReadLine();

            //Data type check for Year of Birth
            while(validInput == 0)
            {
                Console.Write("Year of Birth: ");
                string strYearOfBirth = Console.ReadLine();

                if ( Int32.TryParse(strYearOfBirth, out yearOfBirth))
                {
                    validInput = 1;
                }
                else 
                {
                    Console.WriteLine("Inavlid input. Please try again!");
                }

            }

            //Data type check for Current Year
            validInput = 0;
            while (validInput == 0)
            {
                Console.Write("Current Year: ");
                string strCurrentYear = Console.ReadLine();
                

                if (Int32.TryParse(strCurrentYear, out currentYear))
                {
                    if (currentYear < yearOfBirth)
                    {
                        Console.WriteLine("Invalid input. Current year cannot be less than the year of birth. Please try again!");
                    }
                    else 
                    {
                        validInput = 1;
                    }
                }
                else
                {
                    Console.WriteLine("Inavlid input. Please try again!");
                }

            }

            HeartRates person = new HeartRates(firstName, lastName, yearOfBirth, currentYear);

            Console.WriteLine("\nHeart Rates Information: ");

            Console.WriteLine("First Name: {0}", person.FirstName);
            Console.WriteLine("Last Name: {0}", person.LastName);
            Console.WriteLine("Year of Birth: {0}", person.YearOfBirth);
            Console.WriteLine("\nAge: {0}", person.getAge());
            Console.WriteLine("Maximum Heart Rate: {0}", person.getMaxHeartRate());
            Console.WriteLine("Minimum Target Heart Rate: {0}", person.getMinTargetHeartRate());
            Console.WriteLine("Maximum Target Heart Rate: {0}", person.getMaxTargetHeartRate());
                   
            

        }
    }
}