public class Date
{
    private int month;
    private int day;
    private int year;

    public Date(int month, int day, int year)
    {
        Month = month;
        Year = year;
        Day = day; //Validate day
        Console.WriteLine($"Date object constructor for date {this}");
    }
    public int Year
    {
      get 
      {
        return Year;
      }
      private set
      {
        if (value < = 0)
        {
            throw new ArgumentOutOfRangeException(nameof(value), $"{nameof(Year)}must be 0000");
        }
        year = value;
      }
    }
    public int Month
    {
        get 
        {
            return Month;
        }
        private set
        {
            if(value < = 0 || value > 12)
            {
                throw new ArgumentOutOfRangeException(nameof(value),value,$"{nameof(Month)}must be 1-12");
            }
            month = value;
        }
    }
    public int Day
    {
        get {return day;}
        private set
        {
            int[] daysPerMonth = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            if (value <= 0 || value > daysPerMonth[Month])
            {
                throw new ArgumentOutOfRangeException(nameof(value), value,$"{ nameof(Day) }out of the range for current month/year");
            }
            // Check for leap year
            if (month == 2 && value == 29 && !(Year % 400 == 0 || (Year % 4 == 0 && Year % 100 != 0)))
            {
                throw new ArgumentOutOfRangeException(nameof(value), value,$"{ nameof(Day) }out of the range for current month/year");
            }
            day = value;
        }
    }
    public override stringToString() => $"{Month}/{Day}/{Yeat}";
    internal objectBirthday()
    {
        throw new NotImplementedException();
    }
}
1

public class CommissionEmployee: Employee 
{
    private decimalgrossSales;
    private decimalcommissionRate;
    publicCommissionEmployee(String firstName, String lastName, String socialSecurityNumber,Date birthday, decimal grossSales, decimal commissionRate)
     :base(firstName, lastName, socialSecurityNumber, birthday)
     {
        GrossSales = grossSales;
        CommissionRate = commissionRate;
     }
     public decimalgrossSales
     {
        get 
        {
            return grossSales;
        }
        set
        {
            if(value<0)
            {
                throw new ArgumentOutOfRangeException(nameof(value), value,$"{nameof(GrossSales)}must be>=0");
            }
            grossSales = value;
        }
     }
     public decimalcommissionRate
     {
        get
        {
            return commissionRate;
        }
        set
        {
            if(value < 0|| value >= 1)
            {
                throw new ArgumentOutOfRangeException(nameof(value), value,$"{nameof(CommissionRate)}must be>=0 and < 1");
            }
            commissionRate = value;
        }
     }
     public override decimalEarnings() => CommissionRate * GrossSales;
     public override stringToString() => $"Commision employee: {base.ToString()}n"+ $"Gross Sales: {GrossSales:c}n"+ $"Commission rate:{CommissionRate:F2}";
    
    internal override objectMonth()
    {
        throw new NotImplementedException();
    }
}