using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace RestaurantBillCalculator
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public ObservableCollection<MenuItem> BeverageMenuItems { get; set; } = new ObservableCollection<MenuItem>();
        public ObservableCollection<MenuItem> AppetizerMenuItems { get; set; } = new ObservableCollection<MenuItem>();
        public ObservableCollection<MenuItem> MainCourseMenuItems { get; set; } = new ObservableCollection<MenuItem>();
        public ObservableCollection<MenuItem> DessertMenuItems { get; set; } = new ObservableCollection<MenuItem>();

        private ObservableCollection<OrderItem> _orderItems = new ObservableCollection<OrderItem>();
        public ObservableCollection<OrderItem> OrderItems
        {
            get { return _orderItems; }
            set { _orderItems = value; OnPropertyChanged(); }
        }

        private decimal _total;
        public decimal Total
        {
            get { return _total; }
            set { _total = value; OnPropertyChanged(); }
        }

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the menu items
            BeverageMenuItems.Add(new MenuItem("Water", 1.00m));
            BeverageMenuItems.Add(new MenuItem("Soda", 2.00m));
            BeverageMenuItems.Add(new MenuItem("Coffee", 1.50m));
            AppetizerMenuItems.Add(new MenuItem("Salad", 3.00m));
            AppetizerMenuItems.Add(new MenuItem("Fried Calamari", 6.00m));
            MainCourseMenuItems.Add(new MenuItem("Steak", 12.00m));
            MainCourseMenuItems.Add(new MenuItem("Chicken Alfredo", 10.00m));
            DessertMenuItems.Add(new MenuItem("Cheesecake", 4.00m));
            DessertMenuItems.Add(new MenuItem("Ice Cream", 2.00m));

            // Set the DataContext for the ComboBoxes
            BeverageComboBox.DataContext = this;
            AppetizerComboBox.DataContext = this;
            MainCourseComboBox.DataContext = this;
            DessertComboBox.DataContext = this;

            // Set the DataContext for the DataGrid
            OrderItemsDataGrid.DataContext = this;
        }

        private void AddMenuItemButton_Click(object sender, RoutedEventArgs e)
        {
            ComboBox comboBox = ((FrameworkElement)sender).DataContext as ComboBox;
            MenuItem menuItem = comboBox.SelectedItem as MenuItem;
            OrderItems.Add(new OrderItem(menuItem.Name, menuItem.Price));
            Total += menuItem.Price;
        }

        private void RemoveItemButton_Click(object sender, RoutedEventArgs e)
        {
            OrderItem orderItem = ((FrameworkElement)sender).DataContext as OrderItem;
            Total -= orderItem.Price;
            OrderItems.Remove(orderItem);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class MenuItem
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public MenuItem(string name, decimal price)
        {
            Name = name;
            Price = price;
        }
    }

    public class OrderItem
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public OrderItem(string name, decimal price)
        {
            Name = name;
            Price = price;
        }
    }
}