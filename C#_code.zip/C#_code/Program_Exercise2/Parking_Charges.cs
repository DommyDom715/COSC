using System;
namespace ParkingGarage
{
    class Program
    {
        //Define the minimum fee, hourly rate, and maximum daily charge
        const double MIN_FEE = 2.00;
        const double HOURLY_RATE = 0.50;
        const double MAX_DAILY_CHARGE = 10.00;
        //define the function to calculate the parking charge 
        static doublele CalculateCharges(double hoursParked)
        {
            if (hoursParked <= 3)
            {
                return MIN_FEE;
            }
            else if (hoursParked <= 24)
            {
                return Math.Min(MAX_DAILY_CHARGE, MIN_FEE + HOURLY_RATE * (hoursParked - 3));
            }
            else
            {
                return MAX_DAILY_CHARGE;
            }
        }
        static void Main(string[]args)
        {
            //Initialize the running total of yesterdays receipts
            double totalReciepts = 0.00;
            //Get number of customers
            Console.Write("Enter the number of customers:");
            int numCustomers = int.Parse(Console.ReadLine());
            //Loop over each customer and calculate their charge 
            for (int i = 1; i<= numCustomers; i++)
            {
                Console.Write("Enter the number of hours parked for customer {0}:", i);
                double hoursParked = double.Parse(Console.ReadLine());
                double charge = CalculateCharges(hoursParked);
                totalReceipts += charge;
                Console.WriteLine("Custome {0}: ${1:0.00}",i, charge);
            }
            //print the total receipts for yesterday
            Console.WriteLine("Total receipts: ${0:0.00}", totalReciepts);
        }
    }
}