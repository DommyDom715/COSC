using System;

//diamond class
class diamond
{
    //Shape function
    private static void shape(int n)
    {
        //declare required variables
        int i, j, num =1;
        num = n-1;

        //using nested for loops
        for (j =1; j < = n; j++)
        {
            for (i=1; j<=num; i++)
            Console.Write(" "); //print space
            num--;
            //print asterisk and newline
            for (i = 1; i <=2 * j - 1; i++)
            Console.Write("*");
            Console.WriteLine();
        }
        num = 1;
        //again using nested for loops
        for (j = 1; j <= n - 1; j++)
        {
            for (i = 1; i <= num; i++)
            Console.Write(" "); //print space
            num++;
            //Print asterisk
            for(i=1; i<=2 * (n-j)-1; i++)
            Console.Write("*");
            Console.WriteLine();
        }
    }
    //Main function
    static void Main()
    {
        //call above function
        shape(5);
    }
}
