using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductofOdd
{
    class Program
    {
        static void Main(string[]args)
        {
            int product = 1;
            for (int i = 1; i <=7; i +=2)
            {
                product *= i;
            }
            Console.WriteLine("Product of the odd numbers from 1 to 7 is "+ product);
        }
    }
}