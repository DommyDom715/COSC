using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuplicateWordRemoval
{
    //Program that reads a sentence and prints non duplicate words to console
    class Program
    {
        static void Main(string[]args)
        {
            String sentence;

            //Reading a sentence from user 
            Console.Write("\n Input a sentence:");
            sentence = Console.ReadLine();

            //Splittig the sentece on space
            String[] words = sentence.Split();

            //Runnning LINQ Query on array
            //ToLower function converts the words to lower case 
            //orderby clause order the result set on ascending order 
            //Distict dunction removes the duplicates from the result set

            IEnumerable<String> query = (from word in words orderby word select word.ToLower()).Distinct();

            Console.WriteLine("\n\n Non duplicate words: \n\n");

            //Looping over the result set obtained by running the query
            foreach(String word in query)
            {
                Console.WriteLine(word);
            }
            Console.ReadKey();
        }
    }
}