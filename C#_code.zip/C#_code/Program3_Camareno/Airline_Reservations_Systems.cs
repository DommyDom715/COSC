using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DuplicateElimination
{
    class DupEliminator
    {
        static bool[] totalNumberOfSeats; //initializing total seats
        static int assignedFirstClassSeats = 0;
        static int assignedEconomyClassSeats = 0;

        static void Main(string[] args)
        {
            //console output
            Console.WriteLine(@"This program is an automated airline reservation system. Passengers select their seat by pressing 
            1 for business class and 2 for economy class. If the first class is full you will 
            be asked if you want to book in economy clas if there is an available seat and vice versa. If no 
            seats are available the application will let you know when the next flight is. 
            Make sure you enter capital letter 'Y' for yes and a capital letter 'N' for no.");

            totalNumberOfSeats = new bool[11]; //array
            int selectedClass = 0; //initializing assigned seats

            for (int i = 0; i <= 10; i++) //assigning initial seats to false
            totalNumberOfSeats[i] = false;

            //assigning seats
            for(int i = 1; i <=10; i++)
            {
                //console output
                Console.WriteLine("Enter 1 for First class or 2 for Economy class.");
                selectedClass = Convert.ToInt32(Console.ReadLine());

                //discarding any inputs other than 1 or 2 from the user
                while (selectedClass < 1 || selectedClass > 2)
                {
                    //console output
                    Console.WriteLine("Please enter 1 for first clkass or 2 for Economy class.");
                    selectedClass = Convert.ToInt32(Console.ReadLine());
                }
                //when user is assigned to first class seat
                if (selectedClass == 1)
                {
                    //wheb first clas is ful and their are available seats in economy class
                    if (assignedFirstClassSeats == 5 && assignedEconomyClassSeats < 5)
                    {
                        bool flag = true;
                        while (flag)
                        {
                            Console.WriteLine("First class seat if full. Would you like a seat in Economy class? press uppercase 'Y' for yes and uppercase 'N' for no ");
                            string userInput = Console.ReadLine();
                            if (userInput == 'N') //if the passenger declines Economy class seats
                            {

                                Console.WriteLine("Next plane leave in 3 hours"); //console output
                                i--; //decrement of one
                                break;

                                
                            }
                            else if (userInput == "Y")
                            {
                                assignEconomyClass();
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Entry is not valid");
                            }
                        }
                    }
                    else if (assignedFirstClassSeats < 5)
                    {
                        assignedFirstClassSeats();
                    }
                }
                else
                {
                    //when economy class if full and their are available seats in first class
                    if (assignedEconomyClassSeats == 5 && assignedFirstClassSeats < 5)
                    {
                        bool flag = true;

                        while (flag)
                        {
                            //console output
                            Console.WriteLine("Economy class seat is full. Would you like a seat in first class? press uppercase 'Y' for yes and uppercase 'N' for no");
                            string userInput = Console.ReadLine();
                            if (userInput == "N")
                            {
                                //console output
                                Console.WriteLine("Next plane leaves in 3 hours");
                                i--; //decrement by one
                                break;
                            }
                            else if (userInput == "Y")
                            {
                                assignFirstClass();
                                break;
                            }
                            else
                            {
                                Console.WriteLine("entry is not valid");
                            }
                        }
                    }
                    else
                    {
                        assignEconomyClass();
                    }
                }
            }
            //console output
            Console.WriteLine();
            Console.WriteLine("Sorry, The plane is full. Next one leaves in 3 hours.");
            Console.ReadLine();
        }
        //new method for assigning first class seats
        static void assignFirstClass()
        {
            bool noDuplicate = false;
            Random rand = new Random();
            int index = 0;

            //generates seat number until their are no available seats
            while (!noDuplicate)
            {
                noDuplicate = true;
                index = rand.Next(1, 6); //holds the random generated seats
                if(totalNumberOfSeats[index] == true)
                noDuplicate = false;
            }
            totalNumberOfSeats[index] = true; //taken seats
            assignedFirstClassSeats++; //increase assigned class by one
            Console.WriteLine("assigned seat{0:NO}", index); //Console output
        }
        // new method for assigning second class seats
        static void assignEconomyClass()
        {
            bool noDuplicate = false;
            Random rand = new Random();
            int index = 0;

            //generates seat number until their are no available seat
            while (!noDuplicate)
            {
                noDuplicate = true;
                index = rand.Next(6, 11);
                if (totalNumberOfSeats[index] == true)
                noDuplicate = false;
            }
            totalNumberOfSeats[index] = true; //taken seats

            assignedEconomyClassSeats++; //increase assigned class by one
            Console.WriteLine("assigned seat {0:NO}", index);
        }
    }
}
    