using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CarPoolSavings
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Double click the calculat ebutton and write below code
        private void calcbutton_Click(object sender, EventArgs e)
        {
            double milesdriven;
            double mpg;
            double costOfGas;
            double parkingFees;
            double tollsFee;
            double costPerDay = 0;

            //using try catch block to
            //catch invalid exception
            try
            {
                //get user input from text boxes
                milesdriven = Convert.ToDouble(milestextBox.Text );
                mpg = Convert.ToDouble(mpgtextBox .Text);
                costOfGas = Convert.ToDouble(costPerGallontextBox.Text);
                parkingFees = Convert.ToDouble(parkingtextBox .Text);
                tollsFee = Convert.ToDouble(tollfeetextBox .Text);

                //calculate cost per day
                costPerDay = (milesdriven / mpg) * costOfGas
                            +parkingFees+tollsFee;

                //display result in label
                resultlabel.Text = "Cost per day (Cents) :" + costPerDay;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //close the form
        private void exitbutton_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.Close();
        }
    }
}