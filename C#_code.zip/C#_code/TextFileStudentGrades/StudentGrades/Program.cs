﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Student_Grades2
{
    class Program
    {
        static void Main()
        {
            // Change the path to match where you save the files.
            const string STUDENT_FILE = @"C:\Users\PleaseGod\Desktop\Project 2\Students.txt";
            const string ASSIGNMENT_FILE = @"C:\Users\PleaseGod\Desktop\Project 2\Assignments.txt";

            // First, load the student and assignment data from text files.
            Students students = FileRoutines.LoadStudents(STUDENT_FILE);
            FileRoutines.LoadAssignments(ASSIGNMENT_FILE, students);

            // Next, display information about the students and grades.
            Console.WriteLine("The students and their average are:");
            foreach (Student student in students.StudentList)
            {
                Console.WriteLine("{0,-20}\t{1:N2}", student.FullName, student.GetAverage());
            }

            DisplayStudentsByGrade(students, LetterGrade.A);
            DisplayStudentsByGrade(students, LetterGrade.B);
            DisplayStudentsByGrade(students, LetterGrade.C);
            DisplayStudentsByGrade(students, LetterGrade.D);
            DisplayStudentsByGrade(students, LetterGrade.F);

            Student[] studentsWithHighestAverage = students.GetStudentsWithHighestAverage();
            Console.WriteLine("\nThe students with the highest average are:");
            foreach (Student student in studentsWithHighestAverage)
            {
                Console.WriteLine("{0,-20}\t{1:N2}", student.FullName, student.GetAverage());
            }

            Console.WriteLine("\nThe class average is: {0:N2}", students.GetClassAverage());

            Console.WriteLine("\nThe class average on HW2 is: {0:N2}", students.GetAverageGradeOnAssignment("HW2"));

            Console.ReadLine();
        }

        private static void DisplayStudentsByGrade(Students students, LetterGrade letterGrade)
        {
            Student[] studentList = students.GetStudentsByGrade(letterGrade);

            Console.WriteLine("\nThe following students have a grade of {0}:", letterGrade);
            if (studentList.Length > 0)
            {
                foreach (Student student in studentList)
                {
                    Console.WriteLine("{0,-20}\t{1:N2}", student.FullName, student.GetAverage());
                }
            }
            else
            {
                Console.WriteLine("<none>");
            }
        }
    }
}