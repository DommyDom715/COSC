using System.Runtime.Intrinsics.X86;

weight = input('Enter weight iun pounds: ');
height = input('Enter height in inches: ');
BMI = weight * 703 / height ^ 2;
fprintf('Calculated BMI: %g\n',BMI)
fprintf('Evaluation: ');
if BMI < 18.5
    fprintf('Underweight\n')
elseif BMI <=24.9
    fprintf('Normal\n')
elseif BMI<=29.9
    fprintf('Overweight\n')
else
    fprintf('Obese\n')
end