﻿namespace StudentGrades
{
    partial class Form1
    {
        // Required designer variable.

        private System.ComponentModel.IContainer components = null;

        // Clean up any resources being used.

        // <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))

            {
                components.Dispose();
            }

            base.Dispose(disposing);

        }

        #region Windows Form Designer generated code

        // Required method for Designer support - do not modify

        // the contents of this method with the code editor.

        private void InitializeComponent()
        {
            this.outputBox = new System.Windows.Forms.TextBox();

            this.SuspendLayout();

            // outputBox

            this.outputBox.Location = new System.Drawing.Point(74, 72);

            this.outputBox.Multiline = true;

            this.outputBox.Name = "outputBox";

            this.outputBox.ReadOnly = true;

            this.outputBox.Size = new System.Drawing.Size(346, 215);

            this.outputBox.TabIndex = 0;

            // Form1

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);

            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize = new System.Drawing.Size(496, 388);

            this.Controls.Add(this.outputBox);

            this.Name = "Form1";

            this.Text = "Form1";

            this.Load += new System.EventHandler(this.Form1_Load);

            this.ResumeLayout(false);

            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox outputBox;

    }

}