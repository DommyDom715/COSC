// Dominick Camareno E17.10
public class InorderBinaryTree {
	
	public boolean inorder (Visitor v) {
		if(root == null) {
			return true;
		}
		else 
		{
			if (!inorder(root.left, v)) 
			{
				return false;
			}
			if (!v.visit(root.data)) 
			{
				return false;
			}
			if(!inorder(root.right, v)) 
			{
				return false;
			}
			return true;
		}
		
	}

}
