// Dominick Camareno E17.7

public class BinaryTree {
	
	private Node root;
	
	public BinaryTree() {root = null;}
	
	public BinaryTree(Object rootData) {
		
		root = new Node();
		root.data = rootData;
		root.left = null;
		root.right = null;
	}
	
	public BinaryTree(Object rootData, BinaryTree left, BinaryTree right) {
		
		root = new Node();
		root.data = rootData;
		root.left = left.root;
		root.right = right.root;
	}
	
	class Node{
		
		public Object data;
		public Node left;
		public Node right;
	}
	
	private static int height(Node n) {
		if (n == null) {return 0;}
		else {return 1 + Math.max(height(n.left), height(n.right));}
	}
	
	public int height() {return height(root);}
	
	public boolean isEmpty() {return root == null;}
	
	public Object data() {return root.data;}
	
	public BinaryTree left() {
		
		BinaryTree result = new BinaryTree();
		result.root = root.right;
		return result;
	}
	public BinaryTree right() {
		BinaryTree result = new BinaryTree();
		result.root = root.right;
		return result;
	}
	
	public void preorder() {
		preorder(root);
		System.out.println();
		return;

	}
	private static void preorder(Node n) {
		if(n==null)return;
		System.out.print(n.data+" ");
		preorder(n.left);
		preorder(n.right);
		
	}
	
	public void inorder() {
		inorder(root);
		System.out.println();
		return;
	}
	
	private static void inorder(Node n) {
		if(n==null)return;
		inorder(n.left);
		System.out.print(n.data+" ");
		inorder(n.right);
	}
	public void postorder() {
		postorder(root);
		System.out.println();
		return;
	}
	
	private static void postorder(Node n) {
		if(n==null)return;
		postorder(n.left);
		postorder(n.right);
		System.out.print(n.data + " ");	
	}

}
