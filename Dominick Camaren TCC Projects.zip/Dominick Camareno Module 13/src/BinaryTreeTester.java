// Dominick Camareno E17.7

public class BinaryTreeTester {

	public static void main(String[] args) {
		BinaryTree bt = new BinaryTree(2, new BinaryTree(1), new BinaryTree(3));
		bt.preorder();
		bt.inorder();
		bt.postorder();

	}

}
