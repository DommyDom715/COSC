import java.util.Iterator;
import java.util.List;
import java.util.LinkedList; 
import java.util.Queue;

// Dominick Camareno E17.9

public class Tree {
	
	private Node root;
	
	class Node{
		
		public Object data;
		public List<Node> children;
		
		public int size() {
			int sum = 0;
			for (Node child : children) {sum = sum + child.size();}
			
			return 1 + sum;
		}
	}
	
	public Tree() {
		root = null;
	}
	
	public Tree(Object rootData) {
		root = new Node();
		root.data = rootData;
		root.children = new LinkedList<>();
	}
	
	public void addSubtree(Tree subtree) {
		root.children.add(subtree.root);
	}
	
	public int size() {
		if(root == null) {return 0;}
		else {return root.size();}
	}
	
	public interface Visitor {
		boolean visit(Object data);
	}
	
	public void preorder(Visitor v) {preorder(root, v);}
	
	private static void preorder(Node n, Visitor v) {
		
		if(n == null) {return;}
		v.visit(n.data);
		for(Node c : n.children) {preorder(c, v);}
	}
	
	public void postorder(Visitor v) {postorder(root, v);}
	
	private void postorder(Node n, Visitor v) {
		if (n == null) {return;}
		for (Node c : n.children ) {postorder(c, v);}
		v.visit(n.data);
	}
	
	public void depthFirst(Visitor v) {
		depthFirst(root, v);
	}
	
	private static void depthFirst(Node n, Visitor v) {
		if (n == null) {
			return;
		}
		
		if (v.visit(n.data)) {
			for (Node c : n.children) {
				depthFirst(c, v);
			}
		}
	}
	
	class BreadthFirstIterator implements Iterator{
		private Queue<Node>q;
		
		public BreadthFirstIterator(Node root) {
			q = new LinkedList<>();
			if(root != null) {q.add(root);}
		}
		
		public boolean hasNext() {return q.size()>0;}
		
		public Object next() {
			
			Node n = q.remove();
			for(Node c : n.children) {q.add(c);}
			return n.data;
		}
		public void remove() {throw new UnsupportedOperationException();}
	}
	
	public Iterator iterator() {
		return new BreadthFirstIterator(root);
	}

}
