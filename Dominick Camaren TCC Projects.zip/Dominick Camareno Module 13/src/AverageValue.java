
//Dominick Camareno E17.8

public class AverageValue {
	
	int val;
	AverageValue left;
	AverageValue right;
	private static int sum;
	private static int count;
	private static double average;
	
	public AverageValue(int val) {
		this.val = val;
	}
	
	public int getVal() {
		return val;
	}
	public interface Visitor{
		int visit(AverageValue node);
	}
	
	static class NodeVisitorImpl implements Visitor{
		public int visit (AverageValue node) {
			return node.getVal();
		}
	}
	public void insert(int toInsert) {
		if(toInsert < this.val) {
			if (this.left == null) {
				this.left = new AverageValue(toInsert);
			}else {
				this.left.insert(toInsert);
			}
		}else if (toInsert > this.val) {
			if (this.right == null) {
				this.right = new AverageValue(toInsert);
			}else {
				this.right.insert(toInsert);
			}
		}else {
			System.out.println("Shouldnt have the same value");
		}
	}
	
	public static void inOrder(AverageValue root) {
		if (root == null) {
			return;
		}
		
		Visitor visitor = new NodeVisitorImpl();
		sum += visitor.visit(root);
		count++;
		average = sum/count;
		inOrder(root.left);
		inOrder(root.right);
	}

	public static void main(String[] args) {
		AverageValue root = new AverageValue(4);
		
		root.insert(2);
		root.insert(1);
		root.insert(3);
		root.insert(6);
		root.insert(5);
		root.insert(7);
		
		inOrder(root);
		System.out.println(average);

	}

}
