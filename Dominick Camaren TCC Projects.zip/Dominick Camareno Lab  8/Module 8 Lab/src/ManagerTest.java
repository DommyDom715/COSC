import java.util.Scanner;
//Dominick Camareno E9.1
class ManagerTest {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Manager manager = new Manager();
        System.out.print("Enter name of employee: ");
        manager.setName(in.nextLine());
        System.out.print("Enter name of base salary: ");
        manager.setBaseSalary(in.nextDouble());
        System.out.print("Enter bonus amount: ");
        manager.setBonus(in.nextDouble());

        System.out.println("Employee Name: " + manager.getName());
        System.out.println("Employee Base salary: " + manager.getSalary());
        System.out.println("Employee Bonus: " + manager.getBonus());
    }
}

class Manager extends Employee {

    private double bonus;

    public Manager() {
    }

    public Manager(double bonus) {
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
}

class Employee {
    private String name;
    private double baseSalary;


    public void setName(String newName) {
        name = newName;
    }

    public void setBaseSalary(double newSalary) {
        baseSalary = newSalary;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return baseSalary;
    }
}