//Dominick Camareno E9.2
abstract class BankAccount
{
	double balance;
	public BankAccount()
	{
		balance = 0;

	}

	public BankAccount(double initialBalance)
	{
		balance = initialBalance;

	}

	public abstract void deposit(double amount);
	public abstract void withdraw(double amount);
	public abstract double getBalance();
	}
public class BasicAccount extends BankAccount
{
	public void deposit(double amount)
	{
		balance = balance + amount;
		}
	public void withdraw(double amount)
	{
		if(amount<=balance) {
			balance = balance - amount;}
		else
		{ System.out.println("Sorry! You can't Withdraw:");
		}
		}
	public double getBalance()
	{
		return balance;
		}
	public static void main(String[] args)
	{
		BasicAccount account=new BasicAccount();
		account.deposit(1000);
		account.withdraw(250);
		account.deposit(400);
		
		System.out.println(account.getBalance());
		account.withdraw(5000);

		System.out.println(account.getBalance());
		}

}