public class CheckingAccount {
private double balance;
private int numOverdrafts;
//Dominick Camareno E9.4
public CheckingAccount(double initialBalance) 
{
	balance = initialBalance;

	numOverdrafts = 0;
	}
public void deposit(double amount)
{
	balance += amount;
	}
public void withdraw(double amount) 
{
	balance -= amount;
	if (balance < 0) {
		
		numOverdrafts++;
		
		if (numOverdrafts == 1) 
		{
			balance -= 20;
			}
		else {
			balance -= 30;
			}
		}
	}
public double getBalance() 
{
	return balance;
	}
}

