
//Dominick Camareno E16.2

public class ListTest {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		for(int i=0; i<10; i++) {
			list.addFirst(i);
		}
		
		if(list.size() != 10) {
			
			System.out.println("The addFirst operations have failed!!");
		}
		

	}

}
