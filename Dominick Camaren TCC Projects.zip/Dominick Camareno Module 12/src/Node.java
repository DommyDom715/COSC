//Dominick Camareno E16.4
class Node
{
    Node next;
    int data;
    public Node(){
        data = 0;
        next = null;
    }
    Node(int b){
        this.data = b;
    }
    public int getValue(){
        return data;
    }
    public void setNext(Node b){
        next = b;
    }
    public Node getNext(){
        return next;
    }
    @Override
    public String toString(){
        return data+"";
    }
}


class MyLinkedList{
    private Node head;
    private int numberOfItems;

    MyLinkedList(){
        head= null;
        numberOfItems = 0;
    }

    public int numberOfItems(){
        return numberOfItems;
    }

    public void addNode(int b){
        Node a = new Node(b);
        Node current = head;
        if(head==null){
            head = a;
            numberOfItems++;
            return;
        }

        a.setNext(head);
        head = a;
        numberOfItems++;
        return;
    }

    public void addLast(int b){
        Node a = new Node(b);
        Node current = head;
        if(head==null){
            head = a;
            numberOfItems++;
            return;
        }

        while(current.getNext()!=null){
            current = current.getNext();
        }
        current.setNext(a);
        numberOfItems++;
        return;
    }


    public int deleteNode(int b){

        if(head.getValue()==(b)){
            head = head.getNext();
            numberOfItems--;
            return b;
        }
        Node temp = head.getNext();
        Node prev = head;
        for(int i=1;i<numberOfItems;i++){
//System.out.println(i+" "+temp.getBook());
            if(temp.getValue()==(b)){
                int ans = b;
                prev.setNext(temp.getNext());
                numberOfItems--;
                return b;
            }
            prev = temp;
            temp = temp.getNext();
        }
        return -1;
    }

    public void printNode(Node n){
        System.out.println(n);
    }

    public void printList(){
        Node temp = head;
        while(temp!=null){
            System.out.print(temp.getValue()+"->");
            temp = temp.getNext();
        }
        System.out.println("-->NULL");
    }


    public String toString(){
        String res = "";
        for(Node pos = head;pos!=null;pos = pos.getNext()){
            if(pos.getValue()==-1){
                res += "null";
            }
            else{
                res += pos.getValue();
            }
            if(pos.getNext()!=null)res += "\n";
        }
        return res;
    }

    public int getSize(){
        Node temp = head;
        int ans=0;
        while(temp!=null){
            ans++;
            temp = temp.getNext();
        }
        return ans;
    }
}

