import java.util.Iterator;

//Dominick Camareno E16.3

public class LinkedList2<T>implements Iterable<T> {
	public int sizeof;
	private class ListNode{
		private T data;
		private ListNode next;
		private ListNode(T data) {
			this.data = data;
			next = null;
		}
	}
	private ListNode head;
	private ListNode tail;
	public void LinkedList() {
		head=tail= null;
	}
	public Iterator<T> iterator(){
		return new Iterator<T>() {
			ListNode current = head;
			public boolean hasNext() {
			return current!=null;
			}
			public T next() {
				if(hasNext()) {
					T data = current.data;
					current = current.next;
					return data;
				}
				return null;
			}
			public void remove() {
				throw new UnsupportedOperationException("Remove it and it was not implemented.");
			}
		};
	}

}
