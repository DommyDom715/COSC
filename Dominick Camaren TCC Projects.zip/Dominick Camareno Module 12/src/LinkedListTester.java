//Dominick Camareno E16.4

public class LinkedListTester {

	public static void main(String[] args) {
		
		MyLinkedList list = new MyLinkedList();
		System.out.println("Adding to first");
	    list.addNode(3);
		list.addNode(4);
		list.addNode(5);
		System.out.println(list);
		System.out.println("Adding to last");
		
		list.addLast(6);
		list.addLast(7);
		list.addLast(8);
		System.out.println(list);
		System.out.println("Deleting 7 and 4");
		
		list.deleteNode(7);
		list.deleteNode(4);
		System.out.println(list);
		System.out.println("Size" +list.getSize());

	}

}
