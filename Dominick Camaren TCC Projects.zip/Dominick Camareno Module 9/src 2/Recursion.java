
public class Recursion {
	//Dominick Camareno E13.9
	public static boolean find(String text, String str) {
		if(text.length()==0) {
			return false;
		}
		if(text.length() < str.length()) {
			return false;
		}
		if(text.startsWith(str)) {
			return true;
		}
		return find(text.substring(1),str);
	}

	public static void main(String[] args) {
		boolean ans= find("Mississippi", "sip");
		System.out.println("Does given text contain substring? "+ans);

	}

}
