import java.util.Scanner;

//Dominick Camareno E13.5 Good

public class DecimalToBinary {

	public static String toBinary(int decimal) {
		if(decimal <= 1) {
			return "" + decimal;
		}else {
			return toBinary(decimal / 2) + (decimal % 2);
		}
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a decimal number: ");
		int decimal = in.nextInt();
		System.out.println(decimal + " binary is " + toBinary(decimal));
	}

}
