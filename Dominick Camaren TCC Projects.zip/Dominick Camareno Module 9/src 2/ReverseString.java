//Dominick Camareno E13.7
public class ReverseString {
	public static String reverse(String str) {
		if(str.length() <=1) {
			return str;
		}else {
			return reverse(str.substring(1)) + str.charAt(0);
		}
	}
	
	public static String reverseSubstring(String str,int start,int end) {
		return str.substring(0,start) + reverse(str.substring(start,end)) + str.substring(end,str.length());
	}

	public static void main(String[] args) {
		System.out.println(reverseSubstring("Hello!",0,5));

	}

}
