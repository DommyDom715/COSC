import java.util.Scanner;
public class Main {
	//Dominick Camareno E13.8
	public static void reversed() {
		System.out.println("Enter a string: ");
		Scanner st= new Scanner(System.in);
		String s = st.nextLine();
		int len = s.length();
		StringBuffer output = new StringBuffer();
		for(int x = len - 1;x>=0;x--) 
		{
			output.append(s.charAt(x));
		}
		System.out.println("Reversed string is: ");
		System.out.println(output);
	}

	public static void main(String[] args) {
		
		reversed();

	}

}
