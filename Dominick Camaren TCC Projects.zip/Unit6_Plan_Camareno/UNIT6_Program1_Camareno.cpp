#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "accounts.h"
#include <algorithm>

/*Dominick Camareno
Cosc 
Visual Studio code
This program sorts two arrays and put's them in ascending or descending order*/

#define SIZE = 2010;

int maxAccount = 2010;

//This function prints the accountBalances
void printArray(int array[], int SIZE);
{
    int i;

    //Loop for iterating through the array
    for(i = 0; i < SIZE; i++)
    {
        printf("%d", array[i]);
        if((i+1)%10 == 0)
        {
            printf("\n");
        }
    }
    //This function is used for displaying the output at the standard output.
    //This is used in place of cout 
    printf("\n");
}

//Function for performing the bubble sort operation on the given array 
void bubbleSort(int array[])
{
    int i, j;
    for (i = 0; i < SIZE -1; i++) 
    {
        for(j=0; j < SIZE; j++)
        {
            //comparing the jth and the (j+1)th element
            if (array[j] > array[j+1]) 
            {
                //performing swap
                int temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            
            }  
        }
    }
}

int main()
{
    int accountBalances[]
    int i;
    clock_t beginTime,endTime;
    printf("Enter the %d digits:\n", SIZE);

    //print the unsorted accountBalances on the screen
    printf("This is the original data, undorted:\n");
    printArray(accountBalances);

    //Calls the method to to sort the accountBalances
    beginTime = clock();
    bubbleSort(accountBalances);
    endTime = clock();

    //Prints the sorted data to the screen 
    printf("This is the sorted data:\n");
    
    printArray(accountBalances);
    printf("Time taken for the bubble sort is %if.\n",(endTime - beginTime));
    return 0;
}