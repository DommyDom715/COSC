import java.io.BufferedReader;
import java.io.InputStreamReader;

//Dominick Camareno E15.4

public class Studentinfo {
	static String name[]=new String[100];
	static String grade[]=new String[100];
	static int count=0;
	
	public static void main(String[] args) throws Exception {
		
		int option;
		
		System.out.println("Choose an option");
		System.out.println( " 1) Record a new student \n 2) Modify grade \n 3) Remove student \n 4) Display \n 6) Quit \n");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		option=Integer.parseInt(br.readLine());
		
		while(option<6)
		{
			switch(option)
			{
			case 1:
				record(count);
				count++;
				
				break;
				
			case 2:
				search1();
				break;
				
			case 3:
				remove();
				break;
				
			case 4:
				display();
				break;
				
			case 6:
				break;
				}
			
			System.out.println("choose an option");
			System.out.println( " 1)Record a new student \n 2) modify grade \n 3) remove student \n 4) display \n 6) Quit \n");
			
			option=Integer.parseInt(br.readLine());
			}
		}
	
	static void record(int count) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter name ");
		name[count]=br.readLine();
		System.out.println("grade ");
		}
	
	static void remove() throws Exception
	{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter name of student to be removed");
		String getname=br.readLine();
		int flag=0;
		for(int i=0; i<count; i++)
		{
			if(getname.equalsIgnoreCase(name[i]))
			{
				name[i]="";
				
				grade[i]="";
				
				System.out.println("student removed ");
				
				flag++;
				}
			}
		
		System.out.println(flag+ " records removed");
		}
	
	static void search1() throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter name to search and modify the grade");
		String getname=br.readLine();
		String newgrade;
		
		for(int i=0; i<count; i++)
		{
			if(getname.equalsIgnoreCase(name[i]))
			
			{
				System.out.println("enter new grade");

				newgrade=br.readLine();
				
				grade[i]=newgrade;
				
			}
			
		}
		
		System.out.println("record updated");
		
	}
	
	static void display() throws Exception
	
	{
		boolean exchangeMade;
		
		int pass = 0;
		
		String temp;
		
		exchangeMade = true;
		
		while((pass < count-1) && exchangeMade == true)
		{
			exchangeMade = false;
			
			pass++;
			
			for(int index = 0; index < (count - pass); index++)
			{
				
				if(name[index].compareTo(name[index + 1]) > 0)
				{
					temp = name[index];
					
					name[index] = name[index + 1];
					
					name[index + 1] = temp;
					
					temp = grade[index];
					
					grade[index] = grade[index + 1];
					
					grade[index + 1] = temp;
					
					exchangeMade = true;
					
				}
				
			}
			
		}
		for(int i = 0; i < count; i++)
			System.out.println(name[i] + " " + grade[i] + "\n");
		
	}
	
}

