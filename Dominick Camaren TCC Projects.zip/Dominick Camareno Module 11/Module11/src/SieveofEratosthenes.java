import java.util.*;

//Dominick Camareno E15.3

public class SieveofEratosthenes
{
   public static void main(String[] args) 
   {
   String nString = args[0];
   int n = Integer.parseInt(args[0]);  
   Set<Integer> elems = new TreeSet<Integer>();
   
   for(int i = 2; i <= n; i++)
      {
         elems.add(i);
         
      }
  
   int count = 0; 
  
   
   int factor = 5;
   if (n > 50) { factor = 10; }
   if (n > 100) { factor = 15; }
   if (n > 150) { factor = 20; }
   
   for(int num : elems)
   {
   if(count == factor) { System.out.print("\n"); count = 0;}
   System.out.printf("%4d", num);
   count++;
   }
   
   for( int i = 2; i <= n; i++ )
      {
         getRid( elems, i );
      }
 
   System.out.println( "\n\nPrime numbers found: ");
   count = 0;
   int total = 0;
   int spaces = nString.length() + 1;
   for(int primes : elems)
      {
      	 total++;
         if(count == factor) {System.out.print("\n"); count = 0;}
         count++;
         System.out.printf("%" + spaces + "d", primes);
      }
      System.out.println("\nNumber of primes found: " + total);
   }

   public static Set<Integer> getRid(Set<Integer> numbers, int num)
   {
   Iterator<Integer> cursor = numbers.iterator();
   while(cursor.hasNext())
     {
         int value = cursor.next();
         if(value % num == 0 && value != num) { cursor.remove(); }
     }
     return numbers;
   }
}
	
		  