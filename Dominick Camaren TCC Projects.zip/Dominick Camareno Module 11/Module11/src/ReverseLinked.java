import java.util.LinkedList;
import java.util.Stack;

//Dominick Camareno E15.2

public class ReverseLinked {

	public static void main(String[] args) {
		
		LinkedList<String>employeeName = new LinkedList<String>();
		
		//Avengers Characters 
		employeeName.add("Thor");
		employeeName.add("Rogers");
		employeeName.add("Stark");
		employeeName.add("Banner");
		employeeName.add("Romanoff");
		employeeName.add("Vision");
		System.out.println("Linked list: " + employeeName);
		
		reverse(employeeName);
		

	}
	public static void reverse(LinkedList<String> strings) 
	{
		int size = strings.size();
		
		Stack<String> st = new Stack<String>();
		
		for(int i = 0; i < size; i++) {
			st.push(strings.get(i));
		}
		strings.clear();
		
		while (!st.isEmpty())
		{
			strings.add((String)st.pop());
			System.out.println("Linked list in reverse order: " + strings);
		}
	} 

}
