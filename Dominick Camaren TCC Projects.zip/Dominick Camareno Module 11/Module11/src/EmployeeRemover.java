import java.util.LinkedList;

//Dominick Camareno E15.1

public class EmployeeRemover {
	
	public static void downsize(LinkedList<String> employeeNames, int n) 
	{
		int index = n - 1;
		
		while(index < employeeNames.size()) 
		{
			employeeNames.remove(index);
			
			index += n - 1;
		}
	}
	public static void main(String[] args) {
		LinkedList<String> employeeNames = new LinkedList<String>();
		
		employeeNames.add("e1");
		employeeNames.add("e2");
		employeeNames.add("e3");
		employeeNames.add("e4");
		employeeNames.add("e5");
		employeeNames.add("e6");
		employeeNames.add("e7");
		employeeNames.add("e8");
		employeeNames.add("e9");
		System.out.println("Employees before deletion: " + employeeNames);
		
		downsize(employeeNames, 3);
		System.out.println("Employees after deletion " + employeeNames);

	}

}
