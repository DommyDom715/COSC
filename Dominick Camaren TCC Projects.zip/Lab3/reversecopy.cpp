//Program 1 - Due 6-17-23
// By Dominick Camareno

//This program accepts an int array and creates a copy in reverse

#include <iostream> //required initialistions
using namespace std;


int*reverse_array(const int arr[], const int size){ //method to reverse the array
    int* result = new int[size];
    // iterating over the loop 
    for (int i = 0; i < size; i++){
        result[i] = arr[size - i - 1];
    }
    return result;
}

int main () //main method to get the program to run
{
    int arr[] = {1, 2, 3, 4, 5};
    const int size =5;

    int* reversed_arr = reverse_array (arr, size);

    cout << "Original array: ";
    
    for (int  i = 0; i < size; i++){
        cout << arr[i] << "";
    }
    cout << "Reversed array: ";
    for (int i = 0; i < size; i++){
        cout << reversed_arr[i] << "";
    }
    delete[] reversed_arr;

    return 0;
}