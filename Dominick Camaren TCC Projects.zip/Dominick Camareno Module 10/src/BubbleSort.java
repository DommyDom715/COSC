import java.util.Arrays;

//Dominick Camareno E14.13

public class BubbleSort {
	private static void printArray (int[] a) {
		System.out.println (Arrays.toString (a));
	}
	
	public static int[] bubbleSort (int[]array)	{
		int n = array.length;
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - i - 1; j++) {
				if (array[j] > array [j+1]) {
					int temp = array[j];
					array[j]= array[j+1];
					array[j+1] = temp;
					printArray(array);
				}
			}
		}
		printArray(array);
		return array;
	}

	public static void main(String[] args) {
		int[] testData = { 45, 93, 33, 55};
		
		System.out.println ("Sorting. ");
		testData = bubbleSort (testData);
		System.out.println ("After sorting the array is: ");
		printArray (testData);

	}

}
