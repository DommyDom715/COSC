public class MergeSorter 
{
	//Dominick Camareno E14.4
	
	private int[] a;
	private int[] left_side;
	private int[] right_side;
	
	public MergeSorter (int[] anArray) 
	{
		a = anArray;
	}
	
	public void sort() {
		int size = 1;
		
		int from = 0; 
		int to = a.length - 1;
		
		while (size < to - from) 
		{
			int offset = 0;
			
			while(offset < to) 
			{
				merge(from, to, offset);
				offset = offset + (2 * size);
			}
		}
        size = 2 * size;
    }

    public void merge(int from, int mid, int to)
    {
        System.out.println("Merging " + from + "..." + mid + " and " + (mid + 1) + "..." + to);
    }
}
