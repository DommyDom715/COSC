import java.util.Scanner;

//Dominick Camareno E14.3

public class SelectionSorterDemo {
	public static void main(String[] args) 
	{
		
		int smallest = 0, largest = 0;
		System.out.println("Programs exist on the input of negative or doubles");
		while(true) 
		{
			
			System.out.print("Enter the smallest value of n: ");
			Scanner in = new Scanner(System.in);
			System.out.print("Enter the largest value of n: ");
			largest = in.nextInt();
			if( largest <= 0 || smallest <= 0 )
				System.exit(1);
			for( int i = smallest; i < largest;
					i = i + 10000 ) 
			{
				int[] randomArray =
				ArrTest.randomIntArray(i, 100);
				
				SelectionSorter s = new SelectionSorter(randomArray);
				StopWatch watch = new StopWatch();
				watch.start();
				s.sort();
				watch.stop();
				
				System.out.println("n="+ i);
				System.out.println("Elapsed time: "+ watch.getElapsedTime() + " milliseconds");
			}
			
		}
	}

}
