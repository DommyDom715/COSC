import java.util.Arrays;

//Dominick Camareno E14.4

public class MergeSortDemo {
	
	
	
	public static void main(String[] args) 
	{
		String[] array = new String[] {"Jenny", "Rob", "Dereck", "Mike","Dan",};
		
		System.out.println(Arrays.toString(array));
		
		MergeSorter sorter = new MergeSorter(array);
		sorter.sort();
		System.out.println(Arrays.toString(array));

	}

}
