import java.util.Random;

//Dominick Camareno 14.3

public class ArrTest 
{
	
	private static Random generator = new Random();
	
	public static int[] randomIntArray(int length, int n) 
	{
		int[] a = new int[length];
		for (int i = 0; i < a.length;i++)
			a[i] = generator.nextInt(n);
		
		return a;
	}

}
