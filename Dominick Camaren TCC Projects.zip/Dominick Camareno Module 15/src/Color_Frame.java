import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;

//Dominick Camareno20.5

public class Color_Frame implements ActionListener {
	Frame F;
	Button btnred,btnblue,btngreen;
	public Color_Frame() {
		F = new Frame("Default Frame");
		F.setLayout(new FlowLayout());
		F.setSize(300, 300);
		F.setVisible(true);
		
		btnred = new Button("Red Frame");
		btnred.addActionListener(this);
		F.add(btnred);
		
		btnblue = new Button("Blue Frame");
		btnblue.addActionListener(this);
		F.add(btnblue);
		
		btngreen = new Button("Green Frame");
		btngreen.addActionListener(this);
		F.add(btngreen);
		
		F.add(btnred);
		F.add(btnblue);
		F.add(btngreen);
	}
	public static void main(String[] args) {
		Color_Frame F = new Color_Frame();
	}
	public void actionPerformed(ActionEvent AE) {
		if(AE.getActionCommand() =="Red Frame") {
			F.setTitle("Red Frame");
			F.setBackground(Color.RED);
			F.setVisible(true);
		}
		if(AE.getActionCommand()=="Blue Frame") {
			F.setTitle("Blue Frame");
			F.setBackground(Color.BLUE);
			F.setVisible(true);
		}
		if(AE.getActionCommand()=="Green Frame") {
			F.setTitle("Green Frame");
			F.setBackground(Color.GREEN);
			F.setVisible(true);
		}
	}
}