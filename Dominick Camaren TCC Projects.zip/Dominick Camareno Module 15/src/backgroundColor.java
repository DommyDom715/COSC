//Dominick Camareno E20.2

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ImageIcon;


public class backgroundColor extends JFrame {
	private static final int FRAME_WIDTH = 500;
	private static final int FRAME_HEIGHT = 500;
	private JPanel colorPanel;
	
	public backgroundColor() {
		setTitle("Colored Buttons");
		createColorBackground();
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	private void createColorBackground() {
		colorPanel = new JPanel();
		add(colorPanel, BorderLayout.CENTER);
		buttonColors();
	}
	private void buttonColors() {
		JPanel buttonsPanel = createButtons();
		add(buttonsPanel, BorderLayout.SOUTH);
	}

	private JPanel createButtons() {
		ActionListener listener = new BackgroundColorListener();
		JPanel buttonsPanel = new JPanel(new GridLayout(3,1));
		
		ImageIcon red = new ImageIcon("red.jpg");
		JButton rbutton = new JButton(red);
		rbutton.addActionListener(listener);
		rbutton.setActionCommand("Red");
		
		ImageIcon green = new ImageIcon("green.jpg");
		JButton gbutton = new JButton(green);
		gbutton.addActionListener(listener);
		gbutton.setActionCommand("Green");
		
		ImageIcon blue = new ImageIcon("blue.jpg");
		JButton bbutton = new JButton(blue);
		bbutton.addActionListener(listener);
		bbutton.setActionCommand("Blue");
		
		buttonsPanel.add(rbutton);
		buttonsPanel.add(gbutton);
		buttonsPanel.add(bbutton);
		
		return buttonsPanel;
	}
	
	class BackgroundColorListener
	implements ActionListener {
		
		public void actionPerformed(ActionEvent action) {
			
			if(action.getActionCommand()=="Red")
				colorPanel.setBackground(Color.red);
			else
				if(action.getActionCommand().contentEquals("Green"))
					colorPanel.setBackground(Color.green);
				else
					if(action.getActionCommand().contentEquals("Blue"))
						colorPanel.setBackground(Color.blue);
		}
	}

	public static void main(String[] args) {
		
		new backgroundColor();

	}

}
