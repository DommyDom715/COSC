//Dominick Camareno E20.1

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ColorChange {

	public static void main(String[] args) {
		
		JFrame frame = new JFrame("Color Changing Panel");
		
		JPanel panel = new JPanel();
		panel.setBounds(75,75,130,100);
		panel.setBackground(Color.gray);
		
		JComboBox box = new JComboBox();
		
		box.addItem("Green");
		box.addItem("Red");
		box.addItem("Blue");
		
		box.setBounds(75,10,130,30);
		frame.add(box);
		frame.add(panel);
		
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setSize(300,300);
		frame.setLayout(null);
		frame.setVisible(true);
		
		box.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String color = box.getSelectedItem().toString();
				switch (color) {
				case "Green":
					panel.setBackground(Color.GREEN);
					break;
				case "RED":
					panel.setBackground(Color.RED);
					break;
				case "Blue":
					panel.setBackground(Color.BLUE);
						break;
				}
			}
			
		});

	}

}
