//Dominick Camareno E20.4

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;


public class WindowApplication extends JFrame implements ActionListener{
	
	JPanel colorPanel;
	JPanel checkBoxPanel;
	
	JCheckBox red;
	JCheckBox green;
	JCheckBox blue;
	
	public WindowApplication() {
		super("Window Application");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(400, 378);
		getContentPane().setLayout(null);
		
		colorPanel = new JPanel();
		colorPanel.setBounds(45,21,309,186);
		colorPanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		getContentPane().add(colorPanel);
		
		checkBoxPanel = new JPanel();
		checkBoxPanel.setBounds(10,262,364,54);
		getContentPane().add(checkBoxPanel);
		
		red = new JCheckBox("Red");
		green = new JCheckBox("Green");
		blue = new JCheckBox("Blue");
		
		checkBoxPanel.add(red);
		checkBoxPanel.add(green);
		checkBoxPanel.add(blue);
		
		red.addActionListener(this);
		green.addActionListener(this);
		blue.addActionListener(this);
		
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(red) || e.getSource().equals(green) || e.getSource().equals(blue)) {
			
			int redComponent = 0;
			int greenComponent = 0;
			int blueComponent = 0;
			if(red.isSelected())
				redComponent = 255;
			if(green.isSelected())
				greenComponent = 255;
			if(blue.isSelected())
				blueComponent = 255;
			
			colorPanel.setBackground(new Color(redComponent, greenComponent, blueComponent));
		}
	}

	public static void main(String[] args) {
		
		new WindowApplication();

	}

}
