#include <iostream> 
#include <string>

using namespace std;

int time_of_day(int h, int m, int s)
{
    count <<" please enter hours"
    cin >> h;
    count<< "please enter minutes"
    cin >> m;
    count << "please enter second"
    cin>> s;
    cout<< "The time of day is: " << h << m << s << endl;

    return 0;
}

int app_Date(int day, int month, int year)
{
    count << "please enter day"
    cin>> day;
    count <<: "please enter month"
    cin>> month;
    count<<"please enter year"
    cin>>s;
    cout<<"App Date: " <<day << month << year<< endl;

    return 0;
}

int main() 
{
    //local variable declaration
    int time;
    //time of day function 
    time = time_of_day(int h, int m, int s);
    cout <<"Time is:" <<time<<endl;

    //appDate function

    appDate = app_Date(int day, int month, int year);
    cout<<"Appdate is: "<< appDate <<endl;

    return 0;
}