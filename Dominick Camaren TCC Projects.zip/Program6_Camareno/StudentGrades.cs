namespace Student_Grades2
{
	public class Program
	{
		private static void Main()
		{
			// Change the path to match where you save the files.
			string STUDENT_FILE = @"F:/Volumes/DOM'S FLASH/Program6_Camareno/Students.text";
			
			string ASSIGNMENT_FILE = @"F:/Volumes/DOM'S FLASH/Program6_Camareno/Assignments.text";
			
			// First, load the student and assignment data from text files.
			Students students = FileRoutines.LoadStudents(STUDENT_FILE);
			FileRoutines.LoadAssignments(ASSIGNMENT_FILE, students);

			// Next, display information about the students and grades.
			Console.WriteLine("The students and their average are:");
			foreach(Student student in students.StudentList)
			{
				Console.WriteLine("{0,-20}\t{1:N2}", student.FullName, student.GetAverage());
			}

			DisplayStudentsByGrade(new Students(students), LetterGrade.A);
			DisplayStudentsByGrade(new Students(students), LetterGrade.B);
			DisplayStudentsByGrade(new Students(students), LetterGrade.C);
			DisplayStudentsByGrade(new Students(students), LetterGrade.D);
			DisplayStudentsByGrade(new Students(students), LetterGrade.F);

			Student[] studentsWithHighestAverage = students.GetStudentsWithHighestAverage();
			Console.WriteLine("\nThe students with the highest average are:");
			foreach(Student student in studentsWithHighestAverage)
			{
				Console.WriteLine("{0,-20}\t{1:N2}", student.FullName, student.GetAverage());
			}

			Console.WriteLine("\nThe class average is: {0:N2}", students.GetClassAverage());

			Console.WriteLine("\nThe class average on HW2 is: {0:N2}", students.GetAverageGradeOnAssignment("HW2"));

			Console.ReadLine();
		}

		internal static void DisplayStudentsByGrade(Students students, LetterGrade letterGrade)
		{
			Student[] studentList = students.GetStudentsByGrade(letterGrade);

			Console.WriteLine("\nThe following students have a grade of {0}:", letterGrade);
			if (studentList.Length > 0)
			{
				foreach(Student student in studentList)
				{
					Console.WriteLine("{0,-20}\t{1:N2}", student.FullName, student.GetAverage());
				}
			}
			else
			{
				Console.WriteLine("<none>");
			}
		}
	}
}
