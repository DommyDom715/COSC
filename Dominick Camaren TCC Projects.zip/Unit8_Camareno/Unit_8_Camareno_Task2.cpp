#include <iostream>
using namespace std;
/*Dominick Camareno 
COSC
This program creates a car struct and functions to update its color based on if the year if < or > 2010 */
struct Car
{
    string make;
    string model;
    int year;
    string color;
};

void updateColor(Car *car);
Car&updateColor2(Car *car);

int main()
{
    //Create 2 car objects
    Car car1, car2;

    //initialize all fields of car except color
    car1.make = "Chevy";
    car1.model = "Silverado";
    car1.year = "2008";

    //call updateColor to update the color
    car2 = updateColor2(&car1);

    //display the original and updated car objects
    cout<<"Original Car: Make: "<< car1.make <<"Model:"<<car1.model<<"Year:"<<car1.year<<"Color:"<<car1.color<<endl;
    cout<<"Updated Car: Make:"<<car2.make<<"Model:"<<car2.model<<"Year:"<<"Color"<<car2.color<<endl;

    return 0;
}

//function to update the color of the car
void updateColor(Car *car)
{
    //if year >2010 change color to green 
    if (car ->year > 2010)
    car->color = "Green";
    else //if year is < 2010 change to red
    car->color = "Red";
}

// function to create a new car and update based on the year of the car
Car& updateColor2(Car *car)
{
    Car *updCar = new Car();
    if(car->year>2010)
    updCar->color = "Green";
    else
    updCar->color = "Red";

    return *updCar;
}