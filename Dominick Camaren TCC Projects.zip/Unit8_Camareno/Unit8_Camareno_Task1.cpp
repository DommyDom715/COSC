#include <iostream>
#include <string>

using namespace std;

/*Dominick Camareno 
COSC
This program creats a car struct and a function to update it's color based on the year of the vehicle*/

struct Car
{
    string make;
    string model;
    int year;
    string color;
};

void updateColor(Car *car);

int main()
{
    //Create 3 different car objects
    Car car1, car2, car3;

    //Initialize all fields of car except color
    car1.make = "Chevy";
    car1.model = "Silverado";
    car1.year = 2008;

    car2.make = "Volkswagon";
    car2.model = "Jetta";
    car2.year = 2022;

    car3.make = "Tesla";
    car3.model = "Model 3 Performance";
    car3.year = 2021;

    //Call updateColor to update the color
    updateColor(&car1);
    updateColor(&car2);
    updateColor(&car3);

    //display the car detainls after updating the color
    cout<<"Car1 : Make:"<<car1.make<<"Model:"<<car1.model<<"Year:"<<car1.year<<"Color:"<<car1.color<<endl;
    cout<<"Car2 : Make:"<<car2.make<<"Model:"<<car2.model<<"Year:"<<car2.year<<"Color:"<<car2.color<<endl;
    cout<<"Car1 : Make:"<<car3.make<<"Model:"<<car3.model<<"Year:"<<car3.year<<"Color:"<<car3.color<<endl;

    return 0;
}

//function to update the color of the car
void updateColor(Car *car)
{
    //if year > 2010 update color to Green
    if(car->year>2010)
    car->color = "Green";
    else //if year is 2010 or < update color to Red
    car->color= "Red";
}