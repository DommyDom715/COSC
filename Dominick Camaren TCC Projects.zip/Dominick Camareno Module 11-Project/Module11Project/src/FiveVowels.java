import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;
public class FiveVowels {
	
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		stream.filter(x -> x % 2 == 0)
		.limit(10)
		.count();
		long end = System.currentTimeMillis();
		System.out.println("Time taken: " + (end - start) + "ms");
		
		start = System.currentTimeMillis();
		Stream<Integer> parallelStream = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).parallel();
		parallelStream.filter(x -> x % 2 ==0)
		.limit(10)
		.count();
		end = System.currentTimeMillis();
		System.out.println("Time takes:" + (end - start) + "ms");
	}

}
