import java.util.Arrays;
import java.util.Random;
//Dominick Camareno P19.1
public class RandomInt {
    private static int[] getRandomArray(int size) {
        int[] arr = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(100);
        }
        return arr;
    }

    public static void main(String[] args) {
        int size = 10000000;
        int[] arr = getRandomArray(size);
        for (int n = 10; n <= size; n *= 10) {
            long start = System.currentTimeMillis();
            long evenCount = Arrays.stream(arr).filter(el -> el % 2 == 0).limit(n).count();
            long end = System.currentTimeMillis();
            System.out.println("For n = " + n + ", the regular stream took " + (end - start) + "ms to count the even numbers!");

            start = System.currentTimeMillis();
            evenCount = Arrays.stream(arr).parallel().filter(el -> el % 2 == 0).limit(n).count();
            end = System.currentTimeMillis();
            System.out.println("For n = " + n + ", the parallel stream took " + (end - start) + "ms to count the even numbers!");

            System.out.println();
        }
    }
}