import java.util.*;
//Dominick Camareno P19.2
public class InfiniteStream
{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter value of n: ");
		int n=input.nextInt();
		
		int value=1;
	
		while(n>0)
		{
			
			if(isPerfect(value) && isPalindrome(value))
			{
				System.out.println(value);
				n--;
				
			}
			value++;
			
		}
		
	}

	
	public static boolean isPerfect(int n)
	
	{
		int factor_sum=0;
		for(int i=1;i<n;i++)
		
		{
			if(n%i==0)
				factor_sum+=i;
		}
		return factor_sum==n;
		
	}
	public static boolean isPalindrome(int n)
	{
		return reverse(n)==n;
		}

	public static int reverse(int n)
	
	{
		int reversedValue=0;
		while(n>0)
		{
			reversedValue=reversedValue*10+n%10;
			n=n/10;
			}
		return reversedValue;
}
}