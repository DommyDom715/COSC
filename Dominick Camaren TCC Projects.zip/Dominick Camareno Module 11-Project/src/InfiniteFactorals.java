
import java.util.Map;
import java.util.stream.*;
import java.util.List;
import java.math.BigInteger;

//Dominick Camareno P19.4

 class InfiniteFactoral 
 {
    public static List<String> selectFrom(List<String> lst,char letter){
        char up = Character.toUpperCase(letter);
        char low = Character.toLowerCase(letter);

        Stream<String> word1 = lst.stream()
                .filter(w -> w != null && w.length() > 0)
                .filter(x -> x.toUpperCase().charAt(0) == up);
        Stream<String> word2 = lst.stream()
                .filter(w -> w != null && w.length() > 0)
                .filter(x -> x.toLowerCase().charAt(0) == low);


        List<String> lst1 = word1.collect(Collectors.toList());
                            word2.collect(Collectors.toList());
        return lst1;
    }

    public static Map<Character, List<String>> groupFirstLetter(List<String> lst)
    {
        Map<Character, List<String>> answer = lst.stream()
                .filter(w -> w != null && w.length() > 0)
                .collect(Collectors.groupingBy(w -> Character.valueOf(w.toUpperCase().charAt(0))
                ));

        return answer;
    }

    public static List<BigInteger> fibonacci(int n) 
    {
        return Stream.iterate(new BigInteger[] {BigInteger.ZERO, BigInteger.ONE},
                term -> new BigInteger[] {term[1], term[0].add(term[1])})
                .limit(n)
                .map(arr -> arr[0])
                .collect(Collectors.toList());
    }
    public static List<BigInteger>fibonacci1(int n){
    	return Stream
    			.iterate(new BigInteger[] {BigInteger.ZERO, BigInteger.ONE},
    					term -> new BigInteger[] {term[1], term[0].add(term[1])})
    			.limit(n).map(arr -> arr[0]).collect(Collectors.toList());
    }

}


